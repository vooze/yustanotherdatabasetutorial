#!/bin/bash
cp new_loans.php /var/www
cp old_loans.php /var/www
cp index.html /var/www
cp users.php /var/www

